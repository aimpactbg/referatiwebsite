// File: next.config.ts
// CORRECTED VERSION: The 'swcMinify' option has been removed as it's default now.

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
};

module.exports = nextConfig;